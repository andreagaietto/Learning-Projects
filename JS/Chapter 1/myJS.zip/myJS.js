document.body.style.color = "red";
document.body.style.fontFamily = "Verdana";
alert("Coding with JavaScript")

